define([], () => {
  'use strict';

  class AppModule {
  }
  
   AppModule.prototype.printlog1 = function(input1,input2) {
    console.log("Incoming value");
    console.log(input1);
    console.log(input2);
  };


  AppModule.prototype.isFormValid = function(form) {
              var tracker = document.getElementById(form); 
              if (tracker.valid === "valid") {
                return true;
              } else {
                tracker.showMessages();
                tracker.focusOn("@firstInvalidShown");
                return false;
              }
              };

  return AppModule;
});
