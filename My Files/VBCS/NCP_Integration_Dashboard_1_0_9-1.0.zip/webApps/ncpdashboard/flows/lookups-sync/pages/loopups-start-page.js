define(['vb/helpers/rest', 'ojs/ojdatacollection-utils', 'jsondiff'], function(RestHelper,
  DataCollectionEditUtils, JsonDiffPlugin) {
  'use strict';

  var PageModule = function PageModule() {};

  /**
   * Trigger form validation and return true if form is valid. Form in
   * this recipe is currently editted row.
   */
  PageModule.prototype.isFormValid = function(detail, event) {
console.log("detail");
console.log(detail);
console.log("event");
console.log(event);

    if (detail !== undefined && detail.cancelEdit === true) {
      // skip validation
      console.log("skip validation - true");
      return true;
    }

    // iterate over editable fields which are marked with "editable" class
    // and make sure they are valid:
   // console.log("event.target");
      //console.log(event.target);
    var table = event.target;
    //console.log("table");
      //console.log(table);
      //console.log("table.querySelectorAll('.editable')");
      //console.log(table.querySelectorAll(".editable"));
    var editables = table.querySelectorAll(".editable");
    //console.log("editables");
      //console.log(editables);
    for (var i = 0; i < editables.length; i++) {
      var editable = editables.item(i);

      

      editable.validate();
      // Table does not currently support editables with async validators
      // so treating editable with 'pending' state as invalid
      if (editable.valid !== 'valid') {
        console.log("editable.valid !== 'valid' - false");
        return false;
      }
    }
    console.log("editable.valid !== 'valid' - true");
    return true;
  };


 var JSON_DIFF = JsonDiffPlugin.create({
    arrays: {
      detectMove: false,
    },
    cloneDiffValues: false,
  });

  /**
   * Diffs 2 JSON objects using JsonDiffPlugin which is part of VB and return true
   * if they are different.
   * See https://github.com/benjamine/jsondiffpatch for more info
   */
  PageModule.prototype.areDifferent = function(oldValue, newValue) {
    console.log("oldValue - row data");
    console.log(oldValue);
    console.log("newValue - original row data");
    console.log(newValue);
    var diff = JSON_DIFF.diff(oldValue, newValue);
    return diff !== undefined;
  };

var nextIdValue=0;

 PageModule.prototype.getNextId = function() {   
    --nextIdValue;
    return nextIdValue;
  };


 PageModule.prototype.createBatchPayload_lookupHdr = function(lookupHdrArray, rowStatus, loggedinUser) {
    var payloads = [];
    var record;
    
    Object.keys(rowStatus).forEach(key => {
      var change = rowStatus[key];
      key = parseInt(key);
      if (change === 'inserted') {
        record = lookupHdrArray.find(e => e.lookup_id === key);  

        // default some required fields:      
        
        record.created_by = record.lookup_id;
        record.last_updated_by = record.lookup_id;
        payloads.push(record);
      } else if (change === 'modified') {
        record = lookupHdrArray.find(e => e.lookup_id === key); 
        
        // default some required fields:
        record.last_updated_by = record.lookup_id;   
        payloads.push(record);
      }
    }); 

    return payloads;
  };

   PageModule.prototype.createBatchPayload_lookupDetails = function(lookupDetailsArray, rowStatus, loggedinUser) {
    var payloads = [];
    var record;
    
    Object.keys(rowStatus).forEach(key => {
      var change = rowStatus[key];
      key = parseInt(key);
      if (change === 'inserted') {
        record = lookupDetailsArray.find(e => e.lookup_id === key);  

        // default some required fields:      
        
        record.created_by = record.lookup_id;
        record.last_updated_by = record.lookup_id;
        payloads.push(record);
      } else if (change === 'modified') {
        record = lookupDetailsArray.find(e => e.lookup_id === key); 
        
        // default some required fields:
        record.last_updated_by = record.lookup_id;   
        payloads.push(record);
      }
    }); 

    return payloads;
  };


  // ****************************************getDateTime Conversion**************************************
  PageModule.prototype.getDateTime = function() { 
      var tzoffset = (new Date()).getTimezoneOffset() * 60000; //offset in milliseconds
      var localISOTime = (new Date(Date.now() - tzoffset)).toISOString().substr(0,10);
      console.log("localISOTime");
      console.log(localISOTime);
      return localISOTime;
                  
  };

  return PageModule;
});
