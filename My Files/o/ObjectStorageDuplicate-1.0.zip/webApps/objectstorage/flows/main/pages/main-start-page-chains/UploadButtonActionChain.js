define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class UploadButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callRestObjectStorageAPIsUploadObjectResult = await Actions.callRest(context, {
        endpoint: 'ObjectStorageAPIs/uploadObject',
        uriParams: {
          bucketName: 'bucket-20240803-2133',
          namespaceName: 'axrx85y6xzrs',
          objectName: $page.variables.fileName,
        },
        contentType: $page.variables.fileContent.type,
        body: $page.variables.fileContent,
      });

      if (callRestObjectStorageAPIsUploadObjectResult.status===200) {
        await Actions.fireNotificationEvent(context, {
          summary: 'File Uploaded Successfully',
          displayMode: 'transient',
          type: 'confirmation',
        });

        await Actions.fireDataProviderEvent(context, {
          refresh: null,
          target: $page.variables.getNNamespaceNameBBucketNameOListSDP,
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error while uploading the file',
          type: 'error',
          displayMode: 'transient',
        });
      }

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.fileName',
          '$page.variables.fileContent',
        ],
      });
    }
  }

  return UploadButtonActionChain;
});
