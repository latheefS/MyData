define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PreviewIconClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application } = context;

      const callRestObjectStorageAPIsDownloadObjectResult = await Actions.callRest(context, {
        endpoint: 'ObjectStorageAPIs/downloadObject',
        uriParams: {
          objectName: current.row.name,
          bucketName: 'bucket-20240803-2133',
          namespaceName: 'axrx85y6xzrs',
        },
        responseBodyFormat: 'blob',
      });

      const callFunctionResult = await this.previewFile(context, { data: callRestObjectStorageAPIsDownloadObjectResult.body, mimeType: callRestObjectStorageAPIsDownloadObjectResult.headers.get("content-type"), filename: current.row.name });

      $page.variables.filePreviewBody = 'callFunctionResult';

      const callComponentMethodOjDialog12368728901OpenResult = await Actions.callComponentMethod(context, {
        selector: '#oj-dialog--1236872890-1',
        method: 'open',
      });
    }

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.data 
     * @param {string} params.mimeType 
     * @param {string} params.filename 
     */
    async previewFile(context, { data }) {
      const { $page, $flow, $application } = context;

      const blob = data;

      if (window.navigator && window.navigator.msSaveOrOpenBlob) {

        window.navigator.msSaveOrOpenBlob(blob);

        return;

      }

      return URL.createObjectURL(blob);

    }
  }

  return PreviewIconClickChain;
});
