define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class test extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const response = await Actions.callRest(context, {
        endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
      });

      const response2 = await Actions.callRest(context, {
        endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
      });

      const response3 = await Actions.callRest(context, {
        endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
        uriParams: {
          Display: 'RECEIPT',
        },
      });

      // ---- ASSIGN VARIABLE ---- //
    }
  }

  return test;
});
