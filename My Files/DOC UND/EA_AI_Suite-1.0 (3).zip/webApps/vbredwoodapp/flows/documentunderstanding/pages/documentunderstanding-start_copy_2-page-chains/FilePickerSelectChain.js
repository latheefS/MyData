define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FilePickerSelectChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.files 
     */
    async run(context, { files }) {
      const { $page, $flow, $application } = context;

      $page.variables.objStorageServerBusy = true;
      $page.variables.fileName = files[0].name;
      $page.variables.fileContent = files[0];

      const callRestObjectStorageAPIsUploadObjectResult = await Actions.callRest(context, {
        endpoint: 'ObjectStorageAPIs/UploadObject',
        uriParams: {
          namespaceName: 'v1erp',
          bucketName: 'ent_apps_ai_services',
          objectName: $page.variables.fileName,
        },
        contentType: $page.variables.fileContent.type,
        body: $page.variables.fileContent,
      });

      if (callRestObjectStorageAPIsUploadObjectResult.status === 200) {
        await Actions.fireNotificationEvent(context, {
          summary: 'File Uploaded Successfully',
          displayMode: 'transient',
          type: 'confirmation',
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error While Uploading the file',
          displayMode: 'transient',
          type: 'error',
        });
      }

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.fileName',
          '$page.variables.fileContent',
        ],
      });

      $page.variables.objStorageServerBusy = false;
    }
  }

  return FilePickerSelectChain;
});
