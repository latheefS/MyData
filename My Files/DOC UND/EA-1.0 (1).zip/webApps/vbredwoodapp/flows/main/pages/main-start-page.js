/* Copyright (c) 2024, Oracle and/or its affiliates */

define([], function() {
  'use strict';

  class PageModule {
  }

  return PageModule;
});
