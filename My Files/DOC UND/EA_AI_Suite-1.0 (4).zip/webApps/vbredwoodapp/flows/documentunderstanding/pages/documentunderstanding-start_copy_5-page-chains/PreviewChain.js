define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PreviewChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application } = context;

      $page.variables.filePreview = false;
      $page.variables.objStorageServerBusy = true;

      const callRestObjectStorageAPIsDownloadObjectResult = await Actions.callRest(context, {
        endpoint: 'ObjectStorageAPIs/DownloadObject',
        uriParams: {
          namespaceName: 'v1erp',
          bucketName: 'ent_apps_ai_services',
          objectName: current.row.name,
        },
        responseBodyFormat: 'blob',
      });

      const callFunctionResult = await this.previewFile(context);

      $page.variables.fileBodyForPreview = callFunctionResult;
      $page.variables.filePreview = true;
      $page.variables.objStorageServerBusy = false;
    }

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.data 
     * @param {string} params.mimeType 
     * @param {string} params.filename 
     */
    async previewFile(context, { data }) {
      const { $page, $flow, $application } = context;

      const blob = data;


      // IE/Edge

      if (window.navigator && window.navigator.msSaveOrOpenBlob) {

        window.navigator.msSaveOrOpenBlob(blob);

        return;

      }

      return URL.createObjectURL(blob);

    }
  }

  return PreviewChain;
});
