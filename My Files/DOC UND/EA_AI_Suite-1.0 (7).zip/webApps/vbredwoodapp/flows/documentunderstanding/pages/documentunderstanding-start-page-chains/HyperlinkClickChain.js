define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class HyperlinkClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application } = context;

      $page.variables.filePreview = false;
      $page.variables.objStorageServerBusy = true;

      const callRestObjectStorageAPIsDownloadObjectResult = await Actions.callRest(context, {
        endpoint: 'ObjectStorageAPIs/DownloadObject',
        uriParams: {
          bucketName: 'ent_apps_ai_services',
          namespaceName: 'v1erp',
          objectName: 'current.row.name',
        },
        responseBodyFormat: 'blob',
      });

      const callFunctionResult = await this.preview(context);

      $page.variables.fileBodyForPreview = undefined;
    }

    /**
     * @param {Object} context
     */
    preview(blobData, contentTypeParam) {
      let contentType = contentTypeParam;
      if (contentType === undefined || contentType.length === 0) {
        contentType = "application/octet-stream";
      }
      let newBlob = new Blob([blobData], {
        type: contentType,
      });
      return URL.createObjectURL(newBlob);
    }
  }

  return HyperlinkClickChain;
});
