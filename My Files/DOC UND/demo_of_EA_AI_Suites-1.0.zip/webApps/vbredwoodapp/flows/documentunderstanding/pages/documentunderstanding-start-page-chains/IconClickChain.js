define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class IconClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application } = context;

      const callRestObjectStorageAPIsDownloadObjectResult = await Actions.callRest(context, {
        endpoint: 'ObjectStorageAPIs/DownloadObject',
        uriParams: {
          bucketName: 'ent_apps_ai_services',
          namespaceName: 'v1erp',
          objectName: current.row.name,
        },
        responseBodyFormat: 'blob',
      });

      const callFunctionResult = await this.downloadFile(context, { data: callRestObjectStorageAPIsDownloadObjectResult.body, mimeType: callRestObjectStorageAPIsDownloadObjectResult.headers.get("content-type"), filename: current.row.name });
    }

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.data 
     * @param {string} params.mimeType 
     * @param {string} params.filename 
     */
    async downloadFile(context, { data, mimeType, filename }) {
      const { $page, $flow, $application } = context;

      const blob = data;
      // const blob = new Blob([data], {

      //   type: mimeType

      // });

      // IE/Edge

      if (window.navigator && window.navigator.msSaveOrOpenBlob) {

        window.navigator.msSaveOrOpenBlob(blob);

        return;

      }

      var link = document.createElement('a');

      link.href = URL.createObjectURL(blob);

      link.download = filename;

      link.click();

      // Firefox: delay revoking the ObjectURL

      setTimeout(function () {

        URL.revokeObjectURL(blob);

      }, 100);
    }
  }

  return IconClickChain;
});
