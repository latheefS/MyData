/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class spCancelActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page } = context;

      $page.variables.cancel = true;

      switch ($page.variables.currentStep) {
        case '0':
          await Actions.fireNotificationEvent(context, {
            summary: 'You are already on the home page.',
            displayMode: 'transient',
            type: 'info',
          });
          break;
        case '1':
          const ojStep1CancelDialogOpen2 = await Actions.callComponentMethod(context, {
            selector: '#oj-step1-cancel-dialog',
            method: 'open',
          });
          break;
        case '2':
           const navigateToPageResult = await Actions.navigateToPage(context, {
             '//': 'specify page for navigation',
             page: '',
             params: {
               currentStep: '0',
             },
           });
          break;
        default:
          break;
      }


      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.fileBodyForPreview',
  ],
      });
    }
  }

  return spCancelActionChain;
});