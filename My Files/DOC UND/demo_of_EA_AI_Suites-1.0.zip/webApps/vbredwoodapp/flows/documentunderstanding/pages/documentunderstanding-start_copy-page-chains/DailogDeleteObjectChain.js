define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class DailogDeleteObjectChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      $page.variables.objStorageServerBusy = true;

      const callDeleteObjectChainResponse = await Actions.callRest(context, {
        endpoint: 'ObjectStorageAPIs/DeleteObject',
        uriParams: {
          bucketName: 'ent_apps_ai_services',
          namespaceName: 'v1erp',
          objectName: $page.variables.extractFileName,
        },
      });

      if (callDeleteObjectChainResponse.status === 204) {
        await Actions.fireNotificationEvent(context, {
          summary: 'The object was successfully deleted.',
          displayMode: 'transient',
          type: 'confirmation',
        });

        await Actions.fireDataProviderEvent(context, {
          target: $page.variables.getNNamespaceNameBBucketNameOListSDP,
          refresh: null,
        });

        const ojStep1CancelDialogClose = await Actions.callComponentMethod(context, {
          selector: '#oj-step1-cancel-dialog',
          method: 'close',
        });

        const toDefaultPage = await Actions.navigateToPage(context, {
          page: '',
          params: {
            currentStep: '0',
          },
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Failed to delete the object.',
          displayMode: 'transient',
          type: 'error',
        });
      }

      $page.variables.objStorageServerBusy = false;
    }
  }

  return DailogDeleteObjectChain;
});
