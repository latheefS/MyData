define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class DeleteObjectChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application } = context;

      $page.variables.objStorageServerBusy = true;

      const callRestObjectStorageAPIsDeleteObjectResult = await Actions.callRest(context, {
        endpoint: 'ObjectStorageAPIs/DeleteObject',
        uriParams: {
          bucketName: 'ent_apps_ai_services',
          namespaceName: 'v1erp',
          objectName: current.row.name,
        },
      });

      if (callRestObjectStorageAPIsDeleteObjectResult.status === 204) {
        await Actions.fireNotificationEvent(context, {
          summary: 'The object was successfully deleted.',
          displayMode: 'transient',
          type: 'confirmation',
        });

        await Actions.fireDataProviderEvent(context, {
          target: $page.variables.getNNamespaceNameBBucketNameOListSDP,
          refresh: null,
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Failed to delete the object.',
          displayMode: 'transient',
          type: 'error',
        });
      }

      $page.variables.objStorageServerBusy = false;
    }
  }

  return DeleteObjectChain;
});
