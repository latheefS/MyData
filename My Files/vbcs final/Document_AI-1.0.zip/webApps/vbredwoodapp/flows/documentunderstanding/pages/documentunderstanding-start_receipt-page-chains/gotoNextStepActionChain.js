/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class gotoNextStepActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.event 
     */
    async run(context, { event }) {
      const { $application, $page } = context;
      await Actions.navigateToPage(context, {
        page: $application.currentPage.id,
        params: {
          currentStep: event.detail.nextStep,
        },
        history: "push"
      });

      $page.variables.progressBarVariable = true;
      $page.variables.progressTableDisplayVar = false;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.Receipt_ADP',
    '$page.variables.Receipt_Lines_ADP',
  ],
      });

      const callExtractionResponse = await Actions.callRest(context, {
        endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
        uriParams: {
          filename: $page.variables.extractFileName,
        },
      });

      if (!callExtractionResponse.ok) {
        if (true) {
          await Actions.fireNotificationEvent(context, {
            displayMode: 'persist',
            type: 'error',
            summary: 'Document Processing Failed',
          });

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.progressBarVariable',
    '$page.variables.progressTableDisplayVar',
  ],
          });
        }
      
        return;
      } else {
         const callReceiptResponse = await Actions.callRest(context, {
           endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
           uriParams: {
             Display: 'RECEIPT',
             filename: $page.variables.extractFileName,
           },
         });

        $page.variables.Receipt_ADP.data = callReceiptResponse.body.SelectSQLOutputCollection.SelectSQLOutput;

        const callReceiptLinesResponse = await Actions.callRest(context, {
          endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
          uriParams: {
            Display: 'RECEIPT_LINES',
            filename: $page.variables.extractFileName,
          },
        });

        $page.variables.Receipt_Lines_ADP.data = callReceiptLinesResponse.body.SelectSQLOutputCollection.SelectSQLOutput;

        $page.variables.progressBarVariable = false;
        $page.variables.progressTableDisplayVar = true;
      }


      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.extractFileName',
        ],
      });
    }
  }

  return gotoNextStepActionChain;
});