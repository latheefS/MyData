/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class gotoNextStepActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.event 
     */
    async run(context, { event }) {
      const { $application, $page } = context;
      await Actions.navigateToPage(context, {
        page: $application.currentPage.id,
        params: {
          currentStep: event.detail.nextStep,
        },
        history: "push"
      });

      $page.variables.progressBarVariable = true;
      $page.variables.progressTableDisplayVar = false;

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.Invoice_ADP',
          '$page.variables.Receipt_ADP',
          '$page.variables.Passport_ADP',
        ],
      });

      const callOtherwiseResponse = await Actions.callRest(context, {
        endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
        uriParams: {
          filename: $page.variables.extractFileName,
        },
      });

      if (callOtherwiseResponse.status === 200) {
        const callInvoiceResponse = await Actions.callRest(context, {
          endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
          uriParams: {
            filename: $page.variables.extractFileName,
            Display: 'INVOICE',
          },
        });

        $page.variables.Invoice_ADP.data = callInvoiceResponse.body.SelectSQLOutputCollection.SelectSQLOutput;

        if ($page.variables.Invoice_ADP.data === null || $page.variables.Invoice_ADP.data !== null) {
          const callReceiptResponse = await Actions.callRest(context, {
            endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
            uriParams: {
              Display: 'RECEIPT',
              filename: $page.variables.extractFileName,
            },
          });

          $page.variables.Receipt_ADP.data = callReceiptResponse.body.SelectSQLOutputCollection.SelectSQLOutput;

          if ($page.variables.Receipt_ADP.data === null || $page.variables.Receipt_ADP.data !== null) {
            const callPassportResponse = await Actions.callRest(context, {
              endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
              uriParams: {
                Display: 'PASSPORT',
                filename: $page.variables.extractFileName,
              },
            });

            $page.variables.Passport_ADP.data = callPassportResponse.body.SelectSQLOutputCollection.SelectSQLOutput;
          }
        }
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Extraction Failed',
          displayMode: 'transient',
          type: 'error',
        });
      }

      $page.variables.progressBarVariable = false;
      $page.variables.progressTableDisplayVar = true;
    }
  }

  return gotoNextStepActionChain;
});