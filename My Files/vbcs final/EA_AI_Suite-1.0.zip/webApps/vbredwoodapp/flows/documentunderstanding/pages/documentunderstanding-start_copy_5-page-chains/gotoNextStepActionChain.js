/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class gotoNextStepActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.event 
     */
    async run(context, { event }) {
      const { $application, $page } = context;
      await Actions.navigateToPage(context, {
        page: $application.currentPage.id,
        params: {
          currentStep: event.detail.nextStep,
        },
        history: "push"
      });

      $page.variables.progressBarVariable = true;
      $page.variables.progressTableDisplayVar = false;

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.Invoice_ADP',
          '$page.variables.Receipt_ADP',
          '$page.variables.Passport_ADP',
        ],
      });

      const callOtherwiseResponse = await Actions.callRest(context, {
        endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
        uriParams: {
          filename: $page.variables.extractFileName,
        },
      });

      if (callOtherwiseResponse.status === 200) {

        const results = await Promise.all([
          async () => {

            const callInvoiceResponse = await Actions.callRest(context, {
              endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
              uriParams: {
                filename: $page.variables.extractFileName,
                Display: 'INVOICE',
              },
            });

            $page.variables.Invoice_ADP.data = callInvoiceResponse.body.SelectSQLOutputCollection.SelectSQLOutput;
          },
          async () => {

            const callReceiptResponse = await Actions.callRest(context, {
              endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
              uriParams: {
                filename: $page.variables.extractFileName,
                Display: 'RECEIPT',
              },
            });

            $page.variables.Receipt_ADP.data = callReceiptResponse.body.SelectSQLOutputCollection.SelectSQLOutput;
          },
          async () => {
            const callPassportResponse = await Actions.callRest(context, {
              endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
              uriParams: {
                filename: $page.variables.extractFileName,
                Display: 'PASSPORT',
              },
            });

            $page.variables.Passport_ADP.data = callPassportResponse.body.SelectSQLOutputCollection.SelectSQLOutput;
          },
        ].map(sequence => sequence()));
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Extraction Failed',
          displayMode: 'transient',
          type: 'error',
        });
      }

      $page.variables.progressBarVariable = false;
      $page.variables.progressTableDisplayVar = true;
    }
  }

  return gotoNextStepActionChain;
});