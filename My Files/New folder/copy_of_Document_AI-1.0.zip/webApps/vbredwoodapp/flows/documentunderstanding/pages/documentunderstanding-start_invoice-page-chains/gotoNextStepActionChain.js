/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class gotoNextStepActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.event 
     */
    async run(context, { event }) {
      const { $application, $page } = context;
      await Actions.navigateToPage(context, {
        page: $application.currentPage.id,
        params: {
          currentStep: event.detail.nextStep,
        },
        history: "push"
      });

      $page.variables.progressBarVariable = true;
      $page.variables.progressTableDisplayVar = false;

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.Invoice_ADP',
  ],
      });

      const callExtractionResponse = await Actions.callRest(context, {
        endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
        uriParams: {
          filename: $page.variables.extractFileName,
        },
      });

      if (!callExtractionResponse.ok) {
        if (true) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Document Processing Failed',
            displayMode: 'persist',
            type: 'error',
          });

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.progressBarVariable',
    '$page.variables.progressTableDisplayVar',
  ],
          });
        }
      
        return;
      } else {
         const callInvoiceResponse = await Actions.callRest(context, {
           endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
           uriParams: {
             Display: 'INVOICE',
             filename: $page.variables.extractFileName,
           },
         });

        $page.variables.Invoice_ADP.data = callInvoiceResponse.body.SelectSQLOutputCollection.SelectSQLOutput;

        $page.variables.progressBarVariable = false;
        $page.variables.progressTableDisplayVar = true;
      }


      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.extractFileName',
        ],
      });
    }
  }

  return gotoNextStepActionChain;
});