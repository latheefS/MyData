define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FilePickerSelectChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.files 
     */
    async run(context, { files }) {
      const { $page, $flow, $application } = context;

      $page.variables.objStorageServerBusy = true;
      $page.variables.fileName = files[0].name;
      $page.variables.fileContent = files[0];
      $page.variables.extractFileName = files[0].name;

      const callRestObjectStorageAPIsUploadObjectResult = await Actions.callRest(context, {
        endpoint: 'ObjectStorageAPIs/UploadObject',
        uriParams: {
          objectName: $page.variables.fileName,
          bucketName: 'ent_apps_ai_services',
          namespaceName: 'v1erp',
        },
        body: $page.variables.fileContent,
        contentType: $page.variables.fileContent.type,
      });

      if (callRestObjectStorageAPIsUploadObjectResult.status === 200) {
        await Actions.fireNotificationEvent(context, {
          summary: 'File Uploaded Successfully',
          displayMode: 'transient',
          type: 'confirmation',
        });

        await Actions.fireDataProviderEvent(context, {
          target: $page.variables.getNNamespaceNameBBucketNameOListSDP,
          refresh: null,
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Failed to upload the files',
          displayMode: 'transient',
          type: 'error',
        });
      }

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.fileName',
          '$page.variables.fileContent',
          '$page.variables.fileBodyForPreview',
        ],
      });

      $page.variables.objStorageServerBusy = false;
    }
  }

  return FilePickerSelectChain;
});
