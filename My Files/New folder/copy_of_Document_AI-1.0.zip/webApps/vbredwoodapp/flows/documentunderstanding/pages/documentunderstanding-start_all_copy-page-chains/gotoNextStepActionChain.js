/* Copyright (c) 2024, Oracle and/or its affiliates */

define([
  'vb/action/actionChain',
  'vb/action/actions'
], (
  ActionChain,
  Actions
) => {
  'use strict';

  class gotoNextStepActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.event 
     */
    async run(context, { event }) {
      const { $application, $page } = context;
      await Actions.navigateToPage(context, {
        page: $application.currentPage.id,
        params: {
          currentStep: event.detail.nextStep,
        },
        history: "push"
      });

      $page.variables.progressBarVariable = true;
      $page.variables.progressTableDisplayVar = false;

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.Invoice_ADP',
          '$page.variables.Receipt_ADP',
          '$page.variables.Passport_ADP',
        ],
      });

      const extractionResponse = await Actions.callRest(context, {
        endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTA_COPY1_0Du',
        uriParams: {
          filename: $page.variables.extractFileName,
        },
      });

      if (!extractionResponse.ok) {
        if (true) {
          await Actions.fireNotificationEvent(context, {
            summary: 'Extraction Failed',
          });

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.progressBarVariable',
    '$page.variables.progressTableDisplayVar',
  ],
          });
        }
      
        return;
      } else {
        const invoiceResponse = await Actions.callRest(context, {
          endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTA_COPY1_0Du',
          uriParams: {
            Display: 'INVOICE',
            filename: $page.variables.extractFileName,
          },
        });

        $page.variables.Invoice_ADP.data = invoiceResponse.body.SelectSQLOutputCollection.SelectSQLOutput;

        const receiptResponse = await Actions.callRest(context, {
          endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTA_COPY1_0Du',
          uriParams: {
            Display: 'RECEIPT',
            filename: $page.variables.extractFileName,
          },
        });

        $page.variables.Receipt_ADP.data = receiptResponse.body.SelectSQLOutputCollection.SelectSQLOutput;

        const passportResponse = await Actions.callRest(context, {
          endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTA_COPY1_0Du',
          uriParams: {
            filename: $page.variables.extractFileName,
            Display: 'PASSPORT',
          },
        });

        $page.variables.Passport_ADP.data = passportResponse.body.SelectSQLOutputCollection.SelectSQLOutput;

        $page.variables.progressBarVariable = false;
        $page.variables.progressTableDisplayVar = true;
      }

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.extractFileName',
        ],
      });
    }
  }

  return gotoNextStepActionChain;
});