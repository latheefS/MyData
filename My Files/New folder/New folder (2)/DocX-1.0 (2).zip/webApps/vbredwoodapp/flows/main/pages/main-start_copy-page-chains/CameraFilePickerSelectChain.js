define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CameraFilePickerSelectChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.files 
     */
    async run(context, { files }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.holdImage = files[0];
      $variables.extractFileName = files[0].name;
      $variables.progressBarVariable = true;
      $variables.progressNameVariable = 'File is uploading';
      $variables.progressTableVariable = false;

      $variables.imageURL = URL.createObjectURL($variables.holdImage);

      const uploadObjectResponse = await Actions.callRest(context, {
        endpoint: 'ListObjectsAPI/UploadObjectsAPI',
        uriParams: {
          bucketName: $variables.bucketName,
          namespaceName: $variables.namespaceName,
          objectName: $variables.holdImage.name,
        },
        body: $variables.holdImage,
        contentType: $variables.holdImage.type,
      });

      if (!uploadObjectResponse.ok) {
      
        await Actions.fireNotificationEvent(context, {
          summary: 'Failed',
          message: 'Failed',
          displayMode: 'persist',
          type: 'error',
        });

        return;
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Pass',
          message: 'Pass',
          displayMode: 'transient',
          type: 'confirmation',
        });

        $variables.progressBarVariable = true;
        $variables.progressNameVariable = 'Extracting';
        $variables.progressTableVariable = false;

        const documentExtractionResponse = await Actions.callRest(context, {
          endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
          uriParams: {
            filename: $variables.extractFileName,
          },
        });

        if (!documentExtractionResponse.ok) {
        
          await Actions.fireNotificationEvent(context, {
            summary: 'Extraction Failed',
            message: 'Extraction Failed',
            displayMode: 'persist',
            type: 'error',
          });

          return;
        } else {
          await Actions.fireNotificationEvent(context, {
            summary: 'Extraction Successful',
            message: 'Extraction Successful',
            displayMode: 'transient',
            type: 'confirmation',
          });
        }
      }
    }
  }

  return CameraFilePickerSelectChain;
});
