define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class CameraFilePickerSelectChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.files 
     */
    async run(context, { files }) {
      const { $page, $flow, $application, $constants, $variables } = context;

      $variables.objStorageServerBusy = true;
      $variables.extractFileName = files[0].name;
      $variables.holdImage = files[0];
      $variables.imageURL = URL.createObjectURL($variables.holdImage);
      $variables.progressBarVariable = true;
      $variables.progressTableVariable = false;

      const uploadObjectResponse = await Actions.callRest(context, {
        endpoint: 'ListObjectsAPI/UploadObjectsAPI',
        uriParams: {
          bucketName: $variables.bucketName,
          namespaceName: $variables.namespaceName,
          objectName: $variables.holdImage.name,
        },
        body: $variables.holdImage,
        contentType: $variables.holdImage.type,
      });

      if (!uploadObjectResponse.ok) {
        if (true) {
          await Actions.fireNotificationEvent(context, {
            type: 'error',
            displayMode: 'persist',
            summary: 'Failed to upload the files',
          });

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.objStorageServerBusy',
    '$page.variables.progressBarVariable',
    '$page.variables.progressTableVariable',
  ],
          });
        }
      
        return;
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'File Uploaded Successfully',
          displayMode: 'persist',
          type: 'confirmation',
        });

        const documentExtractionResponse = await Actions.callRest(context, {
          endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
          uriParams: {
            filename: $variables.extractFileName,
          },
        });

        if (!documentExtractionResponse.ok) {
          if (true) {
            await Actions.fireNotificationEvent(context, {
              summary: 'Document processing failed',
              displayMode: 'persist',
              type: 'error',
            });

            await Actions.resetVariables(context, {
              variables: [
    '$page.variables.objStorageServerBusy',
    '$page.variables.progressBarVariable',
    '$page.variables.progressTableVariable',
  ],
            });
          }
        
          return;
        } else {
          await Actions.fireNotificationEvent(context, {
            summary: 'Document processed successfully',
            displayMode: 'transient',
            type: 'confirmation',
          });

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.Invoice_ADP',
    '$page.variables.Receipt_ADP',
    '$page.variables.Passport_ADP',
  ],
          });

          const callInvoiceResponse = await Actions.callRest(context, {
            endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
            uriParams: {
              Display: 'INVOICE',
              filename: $variables.extractFileName,
            },
          });

          $variables.Invoice_ADP = callInvoiceResponse.body.SelectSQLOutputCollection.SelectSQLOutput;

          const callReceiptResponse = await Actions.callRest(context, {
            endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
            uriParams: {
              filename: $variables.extractFileName,
              Display: 'RECEIPT',
            },
          });

          $variables.Receipt_ADP = callReceiptResponse.body.SelectSQLOutputCollection.SelectSQLOutput;

          const callPassportResponse = await Actions.callRest(context, {
            endpoint: 'icsEAAI/getVBCS_DOCUMENT_UNDERSTAND1_0Du',
          });

          $variables.Passport_ADP = callPassportResponse.body.SelectSQLOutputCollection.SelectSQLOutput;

          $variables.progressBarVariable = false;
          $variables.progressTableVariable = true;

          await Actions.resetVariables(context, {
            variables: [
    '$page.variables.objStorageServerBusy',
  ],
          });
        }
      }

      await Actions.resetVariables(context, {
        variables: [
    '$page.variables.extractFileName',
    '$page.variables.objStorageServerBusy',
  ],
      });
    }
  }

  return CameraFilePickerSelectChain;
});
