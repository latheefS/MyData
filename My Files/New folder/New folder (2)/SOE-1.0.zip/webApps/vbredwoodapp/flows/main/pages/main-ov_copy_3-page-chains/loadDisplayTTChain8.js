define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadDisplayTTChain8 extends ActionChain {

    /**
     * Loads DisplayTT record data
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.fetchedFields 
     * @param {string} params.displayTTId 
     */
    async run(context, { fetchedFields, displayTTId = '1' }) {
      const { $page, $flow, $application } = context;

      // Updates form status to Pending.
      $page.variables.displayTTEditFormLoadingStatus = 'pending';

      try {
        // Clears DisplayTT data the variable holds
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.displayTT8',
            '$page.variables.fetchedDisplayTT2',
          ],
        }, { id: 'resetDisplayTTData' });

        // Tests the REST call can be initiated
        if (fetchedFields && fetchedFields.length && displayTTId !== undefined) {
          // Initiates REST call loading DisplayTT data
          const callRestResult = await Actions.callRest(context, {
            endpoint: 'businessObjects/get_DisplayTT',
            responseFields: fetchedFields,
            uriParams: {
              'DisplayTT_Id': displayTTId,
            },
          }, { id: 'loadDisplayTT' });

          if (!callRestResult.ok) {
            // Shows an error message informing about data load failure
            await Actions.fireNotificationEvent(context, {
              summary: 'Could not load data',
              message: `Could not load data: status ${callRestResult.status}`,
            }, { id: 'fireErrorNotification' });

            return;
          }

          // Assigns data loaded by the REST call to the DisplayTT variable
          $page.variables.fetchedDisplayTT2 = callRestResult.body;

          $page.variables.displayTTETag2 = callRestResult.headers.get('ETag');

          // Assigns data loaded by the REST call to the DisplayTT editable record variable
          $page.variables.displayTT8 = $page.variables.fetchedDisplayTT2;
        }
      } finally {
        // Updates form status to Ready.
        $page.variables.displayTTEditFormLoadingStatus = 'ready';
      }
    }
  }

  return loadDisplayTTChain8;
});
