define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadDisplayTTChain4 extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.displayTTId 
     */
    async run(context, { displayTTId = '1' }) {
      const { $page, $flow, $application } = context;

      // Test valid input
      if (true && displayTTId !== undefined) {
        // Clears DisplayTT data the variable holds
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.displayTT4',
          ],
        }, { id: 'resetDisplayTTData' });

        // Initiates REST call loading DisplayTT data
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/get_DisplayTT',
          responseType: 'getDisplayTTResponse3',
          uriParams: {
            'DisplayTT_Id': displayTTId,
          },
        }, { id: 'loadDisplayTT' });

        if (!callRestResult.ok) {
          // Shows an error message informing about data load failure
          await Actions.fireNotificationEvent(context, {
            summary: 'Could not load data',
            message: `Could not load data: status ${callRestResult.status}`,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Assigns data loaded by the REST call to the DisplayTT variable
        $page.variables.displayTT4 = callRestResult.body;
      }
    }
  }

  return loadDisplayTTChain4;
});
