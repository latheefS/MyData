define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createDisplayTTChain extends ActionChain {

    /**
     * Saves changes and creates new DisplayTT record.
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      // Sets the progress variable to true
      $page.variables.createDisplayTTChainInProgress = true;

      try {
        // Validates DisplayTT form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'displayTT-validation-group--1564308791-1',
          },
        }, { id: 'validateDisplayTT' });

        if (!validateFormResult) {
          return;
        }

        // Call REST creating new DisplayTT record
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_DisplayTT',
          body: $page.variables.displayTT8,
        }, { id: 'saveDisplayTT' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new DisplayTT: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Save failed',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Fires a notification event about successful save
        await Actions.fireNotificationEvent(context, {
          summary: 'DisplayTT saved',
          message: 'DisplayTT record successfully created',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        // Resets displayTT variable to the default state
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.displayTT8',
          ],
        }, { id: 'resetDisplayTT' });
      } finally {
        // Sets the progress variable to false
        $page.variables.createDisplayTTChainInProgress = false;
      }
    }
  }

  return createDisplayTTChain;
});
