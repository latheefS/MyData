/* Copyright (c) 2023, Oracle and/or its affiliates */

define([], function() {
  'use strict';

  class FlowModule {
  }

  return FlowModule;
});
