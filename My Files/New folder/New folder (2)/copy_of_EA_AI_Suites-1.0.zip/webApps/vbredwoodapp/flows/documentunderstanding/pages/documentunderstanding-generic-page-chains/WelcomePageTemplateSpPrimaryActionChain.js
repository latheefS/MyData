define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class WelcomePageTemplateSpPrimaryActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callRestObjectStorageAPIsUploadObjectResult = await Actions.callRest(context, {
        endpoint: 'ObjectStorageAPIs/UploadObject',
        uriParams: {
          bucketName: 'ent_apps_ai_services',
          namespaceName: 'v1erp',
          objectName: $page.variables.fileName,
        },
        contentType: $page.variables.fileContent.type,
        type: type,
        body: $page.variables.fileContent,
      });

      if (callRestObjectStorageAPIsUploadObjectResult.status===200) {
        await Actions.fireNotificationEvent(context, {
          displayMode: 'transient',
          type: 'confirmation',
          summary: 'File Uploaded Successfully',
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error occurred  while uploading the file',
          displayMode: 'transient',
          type: 'error',
        });
      }

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.fileName',
          '$page.variables.fileContent',
        ],
      });
    }
  }

  return WelcomePageTemplateSpPrimaryActionChain;
});
