--
--
INSERT
INTO   XXMX_CORE.xxmx_migration_parameters
         (
          parameter_id
         ,application_suite
         ,application
         ,business_entity
         ,sub_entity
         ,parameter_code
         ,parameter_value
         ,enabled_flag
         ,data_source
         )
SELECT    xxmx_migration_parameter_ids_s.NEXTVAL  
         ,'FIN'                                   
         ,'GL'                                    
         ,'HISTORICAL_RATES'                              
         ,'ALL'                                   
         ,'PERIOD_NAME'                           
         ,'APR-15'                                
         ,'Y'                                     
         ,'XXMX'                                  
FROM      dual
WHERE     1 = 1
AND       NOT EXISTS (
                      SELECT 'X'
                      FROM   XXMX_CORE.xxmx_migration_parameters
                      WHERE  1 = 1
                      AND    application_suite = 'FIN'
                      AND    application       = 'GL'
                      AND    business_entity   = 'HISTORICAL_RATES'
                      AND    sub_entity        = 'ALL'
                      AND    parameter_code    = 'PERIOD_NAME'
                      AND    parameter_value   = 'APR-15'
                     );