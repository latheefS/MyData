--
/**************************************
** FIN Metadata (GL) - HISTORICAL RATES
**************************************/
--
/*
** Historical Rates
*/
--
EXECUTE :vn_BusinessEntitySeq := :vn_BusinessEntitySeq + 1;
EXECUTE :vn_SubEntitySeq := 0;
--
EXECUTE :vn_SubEntitySeq := :vn_SubEntitySeq + 1;
--
INSERT
INTO   xxmx_core.xxmx_migration_metadata
         (
         metadata_id
		,application_suite
		,application
		,business_entity_seq
		,business_entity
		,sub_entity_seq
		,sub_entity
		,entity_package_name
		,sql_load_name
		,stg_procedure_name
		,stg_table
		,xfm_procedure_name
		,xfm_table
		,file_gen_procedure_name
		,data_file_name
		,data_file_extension
		,file_group_number
		,enabled_flag
		,simple_xfm_performed_by
		,file_gen_performed_by
		,file_gen_package
		,batch_load
		,seq_in_fbdi_data
		 )
VALUES
         (
          xxmx_migration_metadata_ids_s.NEXTVAL
         ,'FIN'
         ,'GL'
         ,:vn_BusinessEntitySeq
         ,'HISTORICAL_RATES'
         ,:vn_SubEntitySeq
         ,'HISTORICAL_RATES'
         ,'xxmx_gl_historical_rates_pkg'
         ,NULL
         ,'gl_historical_rates_stg'
         ,'XXMX_GL_HISTORICAL_RATES_STG'
         ,NULL
         ,'XXMX_GL_HISTORICAL_RATES_XFM'
         ,NULL
         ,'GlHistoricalRatesInterface'
         ,'csv'
         ,1
         ,'Y'
		 ,NULL
		 ,NULL
		 ,NULL
		 ,NULL
		 ,NULL
         );