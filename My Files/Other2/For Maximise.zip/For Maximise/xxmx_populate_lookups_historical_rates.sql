INSERT
INTO   xxmx_core.xxmx_lookup_values
         (
          application
         ,lookup_type
         ,lookup_code
         ,meaning
         ,description
         ,enabled_flag
         ,seeded
         )
VALUES
         (
          'XXMX'
         ,'BUSINESS_ENTITIES'
         ,'HISTORICAL_RATES'
         ,'Historical Rates'
         ,NULL
         ,'Y'
         ,'Y'
         );
		 
--
--
INSERT
INTO   xxmx_core.xxmx_lookup_values
         (
          application
         ,lookup_type
         ,lookup_code
         ,meaning
         ,description
         ,enabled_flag
         ,seeded
         )
VALUES
         (
          'XXMX'
         ,'SUB-ENTITIES'
         ,'HISTORICAL_RATES'
         ,'Historical Rates'
         ,NULL
         ,'Y'
         ,'Y'
         );