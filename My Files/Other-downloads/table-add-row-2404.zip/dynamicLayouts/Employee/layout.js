/**
 * Copyright (c)2020, 2024, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 */
define([], function() {
  'use strict';

  class LayoutModule {

    getTrainingsValue(fields) {
      let trainingArray = [];
      if (fields.safetyTraining() === "Yes") {
        trainingArray.push("safety");
      }
      if (fields.ethicalTraining() === "Yes") {
        trainingArray.push("ethical");
      }
      if (fields.securityTraining() === "Yes") {
        trainingArray.push("security");
      }
      return trainingArray;
    }

    storeTrainingsChanges(event, fields) {
      const value = event.detail.value;
      let v = value.includes("safety") ? "Yes" : "No";
      if (v !== fields.safetyTraining) {
        fields.safetyTraining( v );
      }
      v = value.includes("ethical") ? "Yes" : "No";
      if (v !== fields.ethicalTraining) {
        fields.ethicalTraining( v );
      }
      v = value.includes("security") ? "Yes" : "No";
      if (v !== fields.securityTraining) {
        fields.securityTraining( v );
      }
    }
  }

  return LayoutModule;
});
