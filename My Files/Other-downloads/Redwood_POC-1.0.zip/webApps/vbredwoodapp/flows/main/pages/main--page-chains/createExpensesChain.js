define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createExpensesChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      // Sets the progress variable to true
      $page.variables.createExpensesChainInProgress = true;

      try {
        // Validates Expenses form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'expenses-validation-group--1231790287-1',
          },
        }, { id: 'validateExpenses' });

        if (!validateFormResult) {
          return;
        }

        // Call REST creating new Expenses record
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_Expenses',
          body: $page.variables.expenses,
        }, { id: 'saveExpenses' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new Expenses: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Save failed',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Fires a notification event about successful save
        await Actions.fireNotificationEvent(context, {
          summary: 'Expenses saved',
          message: 'Expenses record successfully created',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        // Resets expenses variable to the default state
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.expenses',
          ],
        }, { id: 'resetExpenses' });

        // Resets the dynamic form by updating its display value using the value attribute. User entered values will be erased.
        await Actions.callComponentMethod(context, {
          selector: '#oj-dynamic-form--1231790287-1',
          method: 'reset',
        }, { id: 'resetDynamicForm' });
      } finally {
        // Sets the progress variable to false
        $page.variables.createExpensesChainInProgress = false;
      }
    }
  }

  return createExpensesChain;
});
