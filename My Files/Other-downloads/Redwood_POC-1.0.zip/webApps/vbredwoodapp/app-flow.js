/* Copyright (c) 2023, Oracle and/or its affiliates */

define(['oj-sp/spectra-shell/config/config'], function() {
  'use strict';

  var AppModule = function AppModule() {};

  return AppModule;
});
