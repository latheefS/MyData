/* Copyright (c) 2023, Oracle and/or its affiliates */

define([], () => {
  'use strict';
  
  class PageModule {
  }
    
  return PageModule;
});
  