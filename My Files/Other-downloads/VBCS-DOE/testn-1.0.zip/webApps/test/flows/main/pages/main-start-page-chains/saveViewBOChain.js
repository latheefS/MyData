define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class saveViewBOChain extends ActionChain {

    /**
     * Saves ViewBO record data
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.viewBOId 
     */
    async run(context, { viewBOId = '1' }) {
      const { $page, $flow, $application } = context;

      // Updates form status to Pending.
      $page.variables.viewBOEditFormLoadingStatus = 'pending';

      try {
        // Validates ViewBO form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'viewBO-validation-group--490912658-1',
          },
        }, { id: 'validateViewBO' });

        if (!validateFormResult) {
          return;
        }

        const payload = await this.preparePatchPayload(context, {
          updatedRecord: $page.variables.viewBO,
          fetchedRecord: $page.variables.fetchedViewBO,
        });

        if (payload === undefined) {
          // Return from the action chain when there are no changes to save
          return;
        }

        // Initiates REST call saving ViewBO data
        const callRestResult = await Actions.callRest(context, {
          body: payload,
          endpoint: 'businessObjects/update_ViewBO',
          headers: $page.variables.viewBOETag ? { 'If-Match': $page.variables.viewBOETag } : null,
          requestType: 'json',
          uriParams: {
            'ViewBO_Id': viewBOId,
          },
        }, { id: 'saveViewBO' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not edit ViewBO: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
            summary: 'Save failed',
            message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Fires a notification event about successful save
        await Actions.fireNotificationEvent(context, {
          summary: 'ViewBO saved',
          message: 'ViewBO record successfully updated',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        // Calls action chain re-loading ViewBO data
        await Actions.callChain(context, {
          chain: 'loadViewBOChain',
          params: {
            fetchedFields: $page.variables.viewBOEditFormRenderedFields,
          },
        }, { id: 'callLoadViewBOChain' });
      } finally {
        // Updates form status to Ready.
        $page.variables.viewBOEditFormLoadingStatus = 'ready';
      }
    }

    /**
     * Prepares PATCH endpoint payload, calculates changed fields.
     * @param {any} updatedRecord
     * @param {any} fetchedRecord
     * @return {any} calculated payload
     */
    async preparePatchPayload(context, { updatedRecord, fetchedRecord }) {
      let payload = updatedRecord;
      let hasChanges = true;
      if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
        // filter the object to only those top-level fields that differ from the original fetched record
        payload = Object.fromEntries(Object.entries(payload).filter(([field, value]) =>
          JSON.stringify(value) !== JSON.stringify(fetchedRecord?.[field])
        ));
        hasChanges = Object.keys(payload).length > 0;
      }

      if (!hasChanges) {
        payload = undefined;
      }

      return payload;
    }

  }

  return saveViewBOChain;
});
