define([], () => {
  'use strict';

  class PageModule {
  }

  getPeriodPayload(currentRecord) {
    delete currentRecord['isNew'];

    return currentRecord;
  }
  
  return PageModule;
});
