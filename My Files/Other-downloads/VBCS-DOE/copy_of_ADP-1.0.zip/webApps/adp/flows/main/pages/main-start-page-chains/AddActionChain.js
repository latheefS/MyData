define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class AddActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      $page.variables.blankPeriodRowData.id = Math.max(...$page.variables.periodADP.data.map(obj => obj.id)) + 1;

      $page.variables.blankPeriodRowData.isNew = 'Y';

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.periodADP,
        add: {
          data: $page.variables.blankPeriodRowData,
          keys: $page.variables.blankPeriodRowData.id,
        },
      });

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.blankPeriodRowData',
        ],
      });
    }
  }

  return AddActionChain;
});
