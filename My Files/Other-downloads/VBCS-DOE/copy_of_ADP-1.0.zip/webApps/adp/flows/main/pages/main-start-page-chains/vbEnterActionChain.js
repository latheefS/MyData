define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class vbEnterActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callRestBusinessObjectsGetallPeriodResult = await Actions.callRest(context, {
        endpoint: 'businessObjects/getall_Period',
      });

      $page.variables.periodADP.data = callRestBusinessObjectsGetallPeriodResult.body.items;
    }
  }

  return vbEnterActionChain;
});
