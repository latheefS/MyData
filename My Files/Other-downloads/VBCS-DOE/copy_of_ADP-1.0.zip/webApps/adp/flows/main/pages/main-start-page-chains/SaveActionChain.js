define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SaveActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const forEachResult = await ActionUtils.forEach($page.variables.periodADP.data, async (item, index) => {

        if (undefined) {
          const callRestBusinessObjectsUpdatePeriodResult = await Actions.callRest(context, {
            endpoint: 'businessObjects/update_Period',
            uriParams: {
              'Period_Id': $page.variables.periodADP.data[index].id,
            },
            body: $page.functions.getPeriodPayload($page.variables.periodADP.data[index]),
          });
        }

        if ($page.variables.periodADP.data[index].isNew === 'Y') {
          const callRestBusinessObjectsCreatePeriodResult = await Actions.callRest(context, {
            endpoint: 'businessObjects/create_Period',
            body: $page.functions.getPeriodPayload($page.variables.periodADP.data[index]),
          });
        }
      }, { mode: 'serial' });

      await Actions.resetVariables(context, {
      });
    }
  }

  return SaveActionChain;
});
