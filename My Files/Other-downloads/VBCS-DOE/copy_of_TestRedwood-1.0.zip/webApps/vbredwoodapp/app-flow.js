/* Copyright (c) 2023, Oracle and/or its affiliates */

define(['oj-sp/spectra-shell/config/config'], function() {
  'use strict';

  class AppModule {
  }

  return AppModule;
});
