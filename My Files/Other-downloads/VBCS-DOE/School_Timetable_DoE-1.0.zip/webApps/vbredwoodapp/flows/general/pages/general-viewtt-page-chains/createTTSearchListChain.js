define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class createTTSearchListChain extends ActionChain {

    /**
     * Saves changes and creates new TT_SearchList record.
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      // Sets the progress variable to true
      $page.variables.createTTSearchListChainInProgress = true;

      try {
        // Validates TT_SearchList form
        const validateFormResult = await Actions.callChain(context, {
          chain: 'flow:validateFormChain',
          params: {
            validationGroupId: 'tTSearchList-validation-group--636789990-1',
          },
        }, { id: 'validateTTSearchList' });

        if (!validateFormResult) {
          return;
        }

        // Call REST creating new TT_SearchList record
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_TT_SearchList',
          body: $page.variables.tTSearchList,
        }, { id: 'saveTTSearchList' });

        if (!callRestResult.ok) {
          // Create error message
          const errorMessage = callRestResult.body?.detail || callRestResult.body?.['o:errorDetails']?.[0]?.detail || `Could not create new TT_SearchList: status ${callRestResult.status}`;
          // Fires a notification event about failed save
          await Actions.fireNotificationEvent(context, {
              summary: 'Save failed',
              message: errorMessage,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Fires a notification event about successful save
        await Actions.fireNotificationEvent(context, {
          summary: 'TT_SearchList saved',
          message: 'TT_SearchList record successfully created',
          displayMode: 'transient',
          type: 'confirmation',
        }, { id: 'fireSuccessNotification' });

        // Resets tTSearchList variable to the default state
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.tTSearchList',
          ],
        }, { id: 'resetTTSearchList' });
      } finally {
        // Sets the progress variable to false
        $page.variables.createTTSearchListChainInProgress = false;
      }
    }
  }

  return createTTSearchListChain;
});
