define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class loadTTSearchListChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.tTSearchListId 
     */
    async run(context, { tTSearchListId }) {
      const { $page, $flow, $application } = context;

      // Test valid input
      if (true && tTSearchListId !== undefined) {
        // Clears TT_SearchList data the variable holds
        await Actions.resetVariables(context, {
          variables: [
            '$page.variables.tTSearchList2',
          ],
        }, { id: 'resetTTSearchListData' });

        // Initiates REST call loading TT_SearchList data
        const callRestResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/get_TT_SearchList',
          responseType: 'getTTSearchListResponse',
          uriParams: {
            'TT__SearchList_Id': tTSearchListId,
          },
        }, { id: 'loadTTSearchList' });

        if (!callRestResult.ok) {
          // Shows an error message informing about data load failure
          await Actions.fireNotificationEvent(context, {
            summary: 'Could not load data',
            message: `Could not load data: status ${callRestResult.status}`,
          }, { id: 'fireErrorNotification' });

          return;
        }

        // Assigns data loaded by the REST call to the TT_SearchList variable
        $page.variables.tTSearchList2 = callRestResult.body;
      }
    }
  }

  return loadTTSearchListChain;
});
