prompt_dict = {
    "Summary": """
    Please analyze the provided CSV data focusing on the columns u_company, error_message, failed_step, process_id, reasons, result, test_area and test_id. I am particularly interested in obtaining  insights based on the following criteria:
 
    - Analyze the values from the column "error_message" and provide "the most common error message".
    - Analyze the values from the column "reasons" and provide "the most common error reason".
    - Analyze the values from the column "failed_step" and provide "the list of failed steps".
 
    Insights by Test Area:
            - Determine the most common reasons for test failures
            - Failed Test:
            - Failed Test Reason:
            - Failed Step Reason:
    Common Error Messages:
            - Identify the most common error_message across all failed tests.
    Failed Test Reason:
            - The most common reasons for failed tests were
    Failed Step Reason:
            - The most common reasons for failed steps were """
}