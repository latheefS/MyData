/**
 * Copyright (c)2020, 2024, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 */
define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class SingleSelectValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application } = context;

      $page.variables.emp1 = value;

      await Actions.callChain(context, {
        chain: 'loadEmployeeChain',
        params: {
          fetchedFields: $page.variables.employeeDetailFormRenderedFields,
          employeeId: value,
        },
      });
    }
  }

  return SingleSelectValueChangeChain;
});
