define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ojTable16347717241ChangeSelectionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.viewTTId
     */
    async run(context, { viewTTId }) {
      const { $page, $flow, $application } = context;
      $page.variables.oj_table_1634771724_1SelectedId = viewTTId;
    }
  }

  return ojTable16347717241ChangeSelectionChain;
});
