define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class navigateToEditViewTTChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {string} params.viewTTId
     */
    async run(context, { viewTTId }) {
      const { $page, $flow, $application } = context;
      const navigateToPageMainEditViewTtResult = await Actions.navigateToPage(context, {
        page: 'main-edit-view-tt',
        params: {
          viewTTId: viewTTId,
        },
      });
    }
  }

  return navigateToEditViewTTChain;
});
